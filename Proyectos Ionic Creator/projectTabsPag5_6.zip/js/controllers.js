angular.module('app.controllers', [])
  
.controller('page1Ctrl', function($scope) {

})
   
.controller('page2Ctrl', function($scope) {

})
   
.controller('page3Ctrl', function($scope) {

})
      
.controller('page5Ctrl', function($scope) {

})
 