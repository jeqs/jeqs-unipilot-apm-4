angular.module('app.controllers', [])
  
.controller('cameraListCtrl', function($scope) {

})
   
.controller('passRecoveryCtrl', function($scope) {

})
   
.controller('profileCtrl', function($scope) {

})
      
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('sonyCtrl', function($scope) {

})
   
.controller('kodakCtrl', function($scope) {

})
   
.controller('goProCtrl', function($scope) {

})
 