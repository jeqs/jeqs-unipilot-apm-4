angular.module('app.controllers', [])
  
.controller('buttonsCtrl', function($scope) {

})
   
.controller('listCtrl', function($scope) {

})
   
.controller('cardCtrl', function($scope) {

})
 