angular.module('app.controllers', [])
  
.controller('passwordCtrl', function($scope) {

})
      
.controller('listCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('homeCtrl', function($scope) {

})
   
.controller('renaultCtrl', function($scope) {

})
   
.controller('chevroletCtrl', function($scope) {

})
   
.controller('mazadaCtrl', function($scope) {

})
 