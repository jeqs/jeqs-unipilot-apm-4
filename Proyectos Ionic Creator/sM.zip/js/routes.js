angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('menu.password', {
    url: '/page3',
    views: {
      'side-menu21': {
        templateUrl: 'templates/password.html',
        controller: 'passwordCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    abstract:true
  })

  .state('menu.list', {
    url: '/page5',
    views: {
      'side-menu21': {
        templateUrl: 'templates/list.html',
        controller: 'listCtrl'
      }
    }
  })

  .state('login', {
    url: '/page8',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signup', {
    url: '/page9',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('home', {
    url: '/page10',
    templateUrl: 'templates/home.html',
    controller: 'homeCtrl'
  })

  .state('menu.renault', {
    url: '/page11',
    views: {
      'side-menu21': {
        templateUrl: 'templates/renault.html',
        controller: 'renaultCtrl'
      }
    }
  })

  .state('menu.chevrolet', {
    url: '/page12',
    views: {
      'side-menu21': {
        templateUrl: 'templates/chevrolet.html',
        controller: 'chevroletCtrl'
      }
    }
  })

  .state('menu.mazada', {
    url: '/page13',
    views: {
      'side-menu21': {
        templateUrl: 'templates/mazada.html',
        controller: 'mazadaCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page10')

  

});