For the box2d examples you will need PBox2D!

https://github.com/shiffman/PBox2D